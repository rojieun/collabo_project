package page;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.CardLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;

import wineshopping.WineShopCustomer;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.ImageIcon;

public class MainPage extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JButton loginbtn,searchbtn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainPage frame = new MainPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 901, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new GridLayout(0, 3, 0, 0));
		
		JLabel LOGO = new JLabel("");
		LOGO.setIcon(new ImageIcon(MainPage.class.getResource("/page/winelogo.png")));
		panel.add(LOGO);
		
		JLabel blank = new JLabel("");
		panel.add(blank);
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1);
		panel_1.setLayout(new GridLayout(0, 2, 0, 0));
		
		loginbtn = new JButton("");
		loginbtn.setIcon(new ImageIcon(MainPage.class.getResource("/page/login_sq.png")));
		panel_1.add(loginbtn);
		
		
		searchbtn = new JButton("");
		searchbtn.setIcon(new ImageIcon(MainPage.class.getResource("/page/search_sq.png")));
		panel_1.add(searchbtn);
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.CENTER);
		
		JLabel mainimage = new JLabel("");
		mainimage.setIcon(new ImageIcon(MainPage.class.getResource("/page/wine_background.jpg")));
		panel_2.add(mainimage);
		
		loginbtn.addActionListener(this);
		searchbtn.addActionListener(this);		
	}

	//Action �߰��ϱ�
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn=(JButton) e.getSource();
		if(btn==loginbtn) {
			//������ �ִ� ������ WineShopCustomer�� �����ϱ�
			JFrame login = new WineShopCustomer();
			login.setVisible(true);
		}
		if(btn==searchbtn) {
			//�˻�ȭ���� page2�� ����
			JFrame search = new page2();
			search.setVisible(true);
		}
   

	}
}
